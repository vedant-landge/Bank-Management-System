from django.shortcuts import render,redirect, HttpResponseRedirect
from .models import CustomerUser,trx,sc
from django.contrib import auth
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth import login,authenticate
#from .forms import SignUpForm
global user


# Create your views here.
def home(request):
    return render(request, 'home.html', {})

def aboutus(request):
    return render(request, 'about-us.html', {})

def dw(request):
    error = ""
    if request.method == "POST":

        uname = request.POST['uname']
        initialdeposit = request.POST['initialdeposit']
        AC = request.POST['AC']
        depositamt = request.POST['depositamt']
        withdrawamt = request.POST['withdrawamt']

        try:
            trx.objects.create(uname=uname, initialdeposit = initialdeposit,AC = AC,depositamt = depositamt,withdrawamt = withdrawamt )
            error = "no"
        except:
            error = "yes"
    d = {'error': error}
    return render(request, 'dw.html', d)
    '''data = trx.objects.all()
    d ={'data':data}
    return render(request, 'dw.html', d)'''

def userhome(request):
    return render(request, 'userhome.html', {})

def account(request):
    return render(request, 'account.html', {})

def current(request):
    return render(request, 'current.html', {})

def savings(request):
    error = ""
    if request.method == "POST":
        AC = request.POST['AC']
        initialamt = request.POST['initialamt']
        depositamt = request.POST['depositamt']
        withdrawamt = request.POST['withdrawamt']
        balance = request.POST['balance']
        try:
            sc.objects.create(AC=AC, initialamt=initialamt, depositamt=depositamt, withdrawamt=withdrawamt,
                               balance=balance)
            error = "no"
        except:
            error = "yes"
    d = {'error': error}


    return render(request, 'savings.html',d)

def Register(request):
    #return render(request, 'Register.html', {})
    error = ""
    if request.method=="POST":
        fname = request.POST['fname']
        mname = request.POST['mname']
        lname = request.POST['lname']
        uname = request.POST['uname']
        pwd = request.POST['pwd']
        cpwd = request.POST['cpwd']
        mobile = request.POST['mobile']
        email = request.POST['email']
        address = request.POST['address']
        gender = request.POST['gender']
        DOB = request.POST['DOB']
        try:
            CustomerUser.objects.create(fname=fname,mname=mname,lname=lname,uname=uname,pwd=pwd,cpwd=cpwd,mobile=mobile,email=email,address=address,gender=gender,DOB=DOB)
            error = "no"
        except:
            error= "yes"
    d = {'error':error}
    return render(request,'Register.html',d)
'''if request.method == "POST":
        fname = request.POST['fname']
        mname = request.POST['mname']
        lname = request.POST['lname']
        uname = request.POST['uname']
        pwd = request.POST['pwd']
        cpwd = request.POST['cpwd']
        mobile = request.POST['mobile']
        email = request.POST['email']
        address = request.POST['address']
        gender = request.POST['gender']
        DOB = request.POST['DOB']
        if pwd==cpwd:
            if CustomerUser.objects.filter(uname=uname).exists():
                messages.info(request,'Username taken')
                return redirect('Register')
            elif CustomerUser.objects.filter(email=email).exists():
                messages.info(request,'email taken')
                return redirect('Register')
            else:
                user=CustomerUser.objects.create(fname=fname,mname=mname,lname=lname,uname=uname,pwd=pwd,cpwd=cpwd,mobile=mobile,email=email,address=address,gender=gender,DOB=DOB)
                user.save()
                messages.info(request,'User created')

        else:
            print("Sometning went wrong")
            return redirect('Register')
        return redirect('/')
    else:
        return render(request, 'Register.html')'''

'''def Register(request):

    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.save()
            login(request,user)
            return redirect('login')
    else:
        form = SignUpForm()
    return render(request, 'Register.html', {'form': form})'''

'''if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.save()
            raw_password = form.cleaned_data.get('pwd')
            user = authenticate(username=user.username, password=raw_password)
            login(user)
            return redirect('login')
    else:
        form = SignUpForm()
    return render(request, 'register.html', {'form': form})'''

def login(request):
    error = ""
    if request.method == "POST":
        uname=request.POST['uname']
        pwd=request.POST['pwd']
        user = auth.authenticate(uname=uname,pwd=pwd)

        '''if CustomerUser is not None:
            auth.login(request,CustomerUser)
            return redirect('userhome')
        else:
            messages.info(request,'Invalid')
            return redirect('login')
    return render(request,'login.html')'''
        try:
            CustomerUser.objects.get(user=user)
            login(request,user)
            error= "no"
        except:
            error="yes"

    d = {'error':error}
    return render(request, 'login.html',d)

'''def login(request):
    uname = request.POST.get('uname')
    pwd = request.POST.get('pwd')
    if not request.user.is_authenticated:
        return redirect('login')
    data = CustomerUser.objects.filter(uname=uname,pwd=pwd)
    d = {'data': data}
    return render(request, 'userhome.html', d)'''
'''if request.method == "POST":
        form = SignUpForm(request.POST)
        user = form.save()
        raw_password = form.cleaned_data.get('pwd')
        user = authenticate(username=user.username, password=raw_password)
        if user is not None:
            auth.login(request,user)
            return redirect('userhome')
        else:
            messages.info(request,'invalid credentials')
            return redirect('login')
    else:
        return render(request, 'login.html')'''


def logout(request):
    auth.logout(request)
    return redirect('home')





