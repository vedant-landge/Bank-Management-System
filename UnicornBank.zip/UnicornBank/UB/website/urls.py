from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
urlpatterns = [
    path('', views.home, name="home"),
    path('login.html', views.login,  name="login"),
    path('Register.html', views.Register, name="Register"),
    path('about-us.html', views.aboutus, name="about-us"),
    path('dw.html', views.dw, name="dw"),
    path('userhome.html', views.userhome, name="userhome"),
    path('logout.html', views.logout, name="logout"),
    path('account.html', views.account, name="account"),
    path('current.html', views.current, name="current"),
    path('savings.html', views.savings, name="savings"),
]

