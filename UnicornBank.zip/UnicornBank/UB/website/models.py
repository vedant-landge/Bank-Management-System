from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.

class CustomerUser(models.Model):
    fname=models.CharField(max_length=100)
    mname=models.CharField(max_length=100)
    lname=models.CharField(max_length=100)
    uname=models.CharField(max_length=100)
    pwd=models.CharField(max_length=100)
    cpwd=models.CharField(max_length=100)
    mobile=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    address=models.CharField(max_length=200)
    gender=models.CharField(max_length=100)
    DOB=models.CharField(max_length=100)
    class Meta:
        db_table="signup"

class trx(models.Model):
    AC = models.IntegerField(max_length=100)
    uname = models.CharField(max_length=100)
    initialamt = models.IntegerField(max_length=100)
    depositamt = models.IntegerField(max_length=100)
    withdrawamt = models.IntegerField(max_length=100)
    balance = models.IntegerField(max_length=100)
    class Meta:
        db_table="wd"

class sc(models.Model):
    AC = models.IntegerField(max_length=100)
    initialamt = models.IntegerField(max_length=100)
    depositamt = models.IntegerField(max_length=100)
    withdrawamt = models.IntegerField(max_length=100)
    balance = models.IntegerField(max_length=100)
    class Meta:
        db_table="savings"
