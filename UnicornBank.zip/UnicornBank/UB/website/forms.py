from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import CustomerUser

'''class CustomerUser(models.Model):
    fname=models.CharField(max_length=100)
    mname=models.CharField(max_length=100)
    lname=models.CharField(max_length=100)
    uname=models.CharField(max_length=100)
    pwd=models.CharField(max_length=100)
    cpwd=models.CharField(max_length=100)
    mobile=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    address=models.CharField(max_length=200)
    gender=models.CharField(max_length=100)
    DOB=models.CharField(max_length=100)
    class Meta:
        db_table="signup"'''


class SignUpForm(UserCreationForm):
    #full_name = forms.CharField(max_length=100, help_text='Required. 100 charaters of fewer.')
    fname = forms.CharField(max_length=100)
    mname = forms.CharField(max_length=100)
    lname = forms.CharField(max_length=100)
    cpwd = forms.CharField(max_length=100)
    mobile = forms.CharField(max_length=100)
    email = forms.EmailField(max_length=100)
    address = forms.CharField(max_length=200)
    gender = forms.CharField(max_length=100)
    DOB = forms.CharField(max_length=100)

    class Meta:
        model = CustomerUser
        fields = UserCreationForm.Meta.fields + ('fname', 'mname', 'lname', 'cpwd', 'mobile', 'email', 'address', 'gender', 'DOB', )